# [![Davoucii header](https://github.com/dav4thevid/dav4thevid/blob/master/blob/master/icons/cover.png)](https://find-davoucii.netlify.com)
<p align='center'>
<a href="https://dev.to/dav4thevid"><img height="30" src="https://github.com/dav4thevid/dav4thevid/blob/master/blob/master/icons/dev.png?raw=true"></a>&nbsp;&nbsp;
<a href="https://twitter.com/dav4thevid"><img height="30" src="https://github.com/dav4thevid/dav4thevid/blob/master/blob/master/icons/twitter.png?raw=true"></a>&nbsp;&nbsp;
<a href="https://facebook.com/dav4thevid"><img height="30" src="https://github.com/dav4thevid/dav4thevid/blob/master/blob/master/icons/facebook.png?raw=true"></a>&nbsp;&nbsp;
<a href="https://www.buymeacoffee.com/dav4thevid"><img height="30" src="https://github.com/WaylonWalker/WaylonWalker/blob/main/icon/by-me-a-coffee.png?raw=true"></a>
<a href="https://www.linkedin.com/in/davoucii/"><img height="30" src="https://github.com/dav4thevid/dav4thevid/blob/master/blob/master/icons/linkedin.png?raw=true"></a>
</p>




![](https://komarev.com/ghpvc/?username=your-github-username&color=green)

Hey there 👋,

I have a passion for learning and sharing my knowledge with others a public as possible.  You can see a full list of what I am up to on [davouciii.netlify.com](waylonwalker.com).  If you found value in something I have created, please feel free to send a [tip](https://www.buymeacoffee.com/davoucii), or give me a shout out [@dav4thevid](https://twitter.com/dav4thevid), || [@dav4thevid](https://facebook.com/dav4thevid) give some ♥ on [DEV.to/dav4thevid](https://dev.to/dav4thevid)
 
  ---
 
 <p>
  <img width="250" align='left' src="https://github.com/WaylonWalker/WaylonWalker/blob/main/icon/hacktoberfest.png?raw=true">
</p>
 
### Boy Scout Rule

I love open source.  I am not a heavy maintainer of any large libraries, but I really like the boyscout rule.  I contribute to things as I come across issues that I think other people might struggle with.

 ---

<p align="center"> <img src="https://github-readme-stats.vercel.app/api?username=dav4thevid&show_icons=true" alt="dav4thevid" /> </p>
